package chaoshiquan;

public abstract class Shijuan {
    public abstract void testQuestion1();
    public abstract void testQuestion2();
    public abstract void testQuestion3();
    public void Shijuan()
    {
        testQuestion1();
        testQuestion2();
        testQuestion3();
    }
}

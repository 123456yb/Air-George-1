package chaoshiquan;

public class Xuesheng1 extends Shijuana{
    @Override
    protected String answer1() {
        return "a";
    }
    @Override
    protected String answer2() {
        return "b";
    }
    @Override
    protected String answer3() {
        return "c";
    }
}

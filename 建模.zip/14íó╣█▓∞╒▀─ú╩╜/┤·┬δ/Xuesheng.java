package guanchazhe;

public abstract class Xuesheng {
    public abstract void update();
}

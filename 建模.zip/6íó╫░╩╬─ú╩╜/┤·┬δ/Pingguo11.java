package zhuangshi;

public class Pingguo11 extends Chuanda {
    public void show() {
        super.show();
        System.out.println("苹果11");
    }
}

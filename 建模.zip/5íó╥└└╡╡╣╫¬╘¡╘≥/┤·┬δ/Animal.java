package lishi;
public class Animal {
    private String Chi;
   private String He;
   private String Pao;
   private String Jiao;

    public String getChi() {
        return Chi;
    }

    public String getHe() {
        return He;
    }

    public String getPao() {
        return Pao;
    }

    public String getJiao() {
        return Jiao;
    }
}

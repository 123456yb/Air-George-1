package waiguan;

public class SubSystemFour {
    public void methodFour()
    {
        System.out.println("卖出500B股");
    }
}

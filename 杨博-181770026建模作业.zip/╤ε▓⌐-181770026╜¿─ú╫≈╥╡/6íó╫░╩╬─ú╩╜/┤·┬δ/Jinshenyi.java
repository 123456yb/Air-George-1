package zhuangshi;

public class Jinshenyi extends Chuanda{
    public void show() {
        super.show();
        System.out.println("紧身衣");
    }
}

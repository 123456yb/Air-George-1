package zhuangshi;

public class Lingdai extends Chuanda {
    public void show() {
        super.show();
        System.out.println("领带");
    }
}

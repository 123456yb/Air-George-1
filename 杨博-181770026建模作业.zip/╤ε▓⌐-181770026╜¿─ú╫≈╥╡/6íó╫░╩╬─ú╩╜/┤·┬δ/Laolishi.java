package zhuangshi;

public class Laolishi extends Chuanda{
    public void show() {
        super.show();
        System.out.println("戴劳力士");
    }
}

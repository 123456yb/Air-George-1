package zhuangshi;

public class Xizhuang extends Chuanda {
    public void show() {
        super.show();
        System.out.println("西装");
    }
}

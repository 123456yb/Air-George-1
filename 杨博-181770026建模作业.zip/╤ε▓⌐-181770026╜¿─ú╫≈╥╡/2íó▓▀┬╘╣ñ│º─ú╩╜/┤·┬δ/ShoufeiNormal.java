package celue;

public class ShoufeiNormal implements Shoufei {
    @Override
    public double shoufei(double money) {
        return money;
    }
}

public class Khd {
    public static void main(String[] args) {
        Bzqz jiaojiao =new Bzqz();
        jiaojiao.setName("女神");
        daili daili1 =new daili(jiaojiao);
        daili1.getfellow();
        daili1.getqiaokeli();
        daili1.getxiaodao();
    }
}

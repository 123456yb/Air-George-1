package waiguan;

public class SubSystemThree {
    public void methodThree()
    {
        System.out.println("卖出200A股");
    }
}

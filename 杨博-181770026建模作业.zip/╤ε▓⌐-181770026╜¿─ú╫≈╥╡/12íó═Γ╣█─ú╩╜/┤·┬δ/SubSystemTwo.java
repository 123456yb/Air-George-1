package waiguan;

public class SubSystemTwo {
    public void methodTwo()
    {
        System.out.println("买入1000B股");
    }
}

package waiguan;

public class SubSystemOne {
    public void methodOne()
    {
        System.out.println("买入500A股");
    }
}

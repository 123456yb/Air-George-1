package waiguan;

public class khd {
    public static void main(String[] args) {
        Facade facade =new Facade();
        facade.methodA();
        facade.methodB();
        facade.methodC();
        facade.methodD();
    }
}

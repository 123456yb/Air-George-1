package gongchang;

public class Undergraduate extends Teacher {
}

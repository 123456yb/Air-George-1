package gongchang;

public class Teacher {
    public void a()
    {
        System.out.println("教书");
    }

    public void b()
    {
        System.out.println("授课");
    }

    public void c()
    {
        System.out.println("解惑");
    }
}

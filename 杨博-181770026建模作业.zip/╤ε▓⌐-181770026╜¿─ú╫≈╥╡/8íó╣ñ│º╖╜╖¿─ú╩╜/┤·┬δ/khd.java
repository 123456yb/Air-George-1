package gongchang;

public class khd {
    public static void main(String[] args)
    {
        Teacher danglaoshi = new Undergraduate();
        danglaoshi.a();
        danglaoshi.b();
        danglaoshi.c();
    }
}

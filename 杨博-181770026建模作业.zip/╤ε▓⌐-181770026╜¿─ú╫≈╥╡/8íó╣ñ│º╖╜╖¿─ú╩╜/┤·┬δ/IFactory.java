package gongchang;

public interface IFactory {
    Teacher createteacher();
}
